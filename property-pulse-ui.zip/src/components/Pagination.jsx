import React from "react";

const Pagination = () => {
  return (
    <section class="container mx-auto flex justify-center items-center my-8">
      <button class="mr-2 px-2 py-1 border border-gray-300 rounded">
        Previous
      </button>
      <span class="mx-2"> Page 1 of 10 </span>
      <button class="ml-2 px-2 py-1 border border-gray-300 rounded">
        Next
      </button>
    </section>
  );
};

export default Pagination;
