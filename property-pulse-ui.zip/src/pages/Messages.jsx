import React from "react";
import MessageCard from "../components/MessageCard";

const Messages = () => {
  return (
    <div>
      <section class="bg-blue-50">
        <div class="container m-auto py-24 max-w-6xl">
          <div class="bg-white px-6 py-8 mb-4 shadow-md rounded-md border m-4 md:m-0">
            <h1 class="text-3xl font-bold mb-4">Your Messages</h1>

            <MessageCard />
            <MessageCard />
            <MessageCard />
            <MessageCard />
          </div>
        </div>
      </section>
    </div>
  );
};

export default Messages;
