import React from "react";

const Register = () => {
  return (
    <>
      <section class="bg-blue-50 min-h-screen flex-grow">
        <div class="container m-auto max-w-lg py-24">
          <div class="bg-white px-6 py-8 mb-4 shadow-md rounded-md border m-4 md:m-0">
            {/* <!-- Register Form--> */}
            <form>
              <h2 class="text-3xl text-center font-semibold mb-6">
                Create An Account
              </h2>

              {/* <!-- Name --> */}
              <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">Name</label>
                <input
                  type="text"
                  id="name"
                  name="name"
                  class="border rounded w-full py-2 px-3 mb-2"
                  placeholder="Full name"
                  required
                />
              </div>

              {/* <!-- Email --> */}
              <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">Email</label>
                <input
                  type="email"
                  id="email"
                  name="email"
                  class="border rounded w-full py-2 px-3 mb-2"
                  placeholder="Email address"
                  required
                />
              </div>

              {/* <!-- Password --> */}
              <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">
                  Password
                </label>
                <input
                  type="password"
                  id="password"
                  name="password"
                  class="border rounded w-full py-2 px-3 mb-2"
                  placeholder="Password"
                  required
                />
              </div>

              {/* <!-- Password --> */}
              <div class="mb-4">
                <label class="block text-gray-700 font-bold mb-2">
                  Confirm Password
                </label>
                <input
                  type="password"
                  id="password2"
                  name="password2"
                  class="border rounded w-full py-2 px-3 mb-2"
                  placeholder="Confirm Password"
                  required
                />
              </div>

              {/* <!-- Submit Button --> */}
              <div>
                <button
                  class="bg-blue-500 hover:bg-blue-600 text-white font-bold py-2 px-4 rounded-full w-full focus:outline-none focus:shadow-outline"
                  type="submit"
                >
                  Register
                </button>
              </div>
            </form>
          </div>
        </div>
        <div class="flex-grow"></div>
      </section>
    </>
  );
};

export default Register;
