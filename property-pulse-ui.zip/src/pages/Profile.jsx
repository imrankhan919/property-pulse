import ProfileImage from "../assets/profile.png";
import ListingCard from "../components/ListingCard";
const Profile = () => {
  return (
    <>
      <section class="bg-blue-50">
        <div class="container m-auto py-24">
          <div class="bg-white px-6 py-8 mb-4 shadow-md rounded-md border m-4 md:m-0">
            <h1 class="text-3xl font-bold mb-4">Your Profile</h1>
            <div class="flex flex-col md:flex-row">
              <div class="md:w-1/4 mx-20 mt-10">
                <div class="mb-4">
                  <img
                    class="h-32 w-32 md:h-48 md:w-48 rounded-full mx-auto md:mx-0"
                    src={ProfileImage}
                    alt="User"
                  />
                </div>
                <h2 class="text-2xl mb-4">
                  <span class="font-bold block">Name: </span> John Doe
                </h2>
                <h2 class="text-2xl">
                  <span class="font-bold block">Email: </span> john@gmail.com
                </h2>
              </div>

              <div class="md:w-3/4 md:pl-4">
                <h2 class="text-xl font-semibold mb-4">Your Listings</h2>

                <ListingCard />
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Profile;
