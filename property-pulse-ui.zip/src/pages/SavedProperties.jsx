import React from "react";
import PropertyCard from "../components/PropertyCard";
import Pagination from "../components/Pagination";

const SavedProperties = () => {
  return (
    <>
      <section class="px-4 py-6">
        <div class="container-xl lg:container m-auto px-4 py-6">
          <h1 class="text-3xl font-bold mb-6">Your Saved Properties</h1>
          <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <PropertyCard />
          </div>
          <Pagination />
        </div>
      </section>
    </>
  );
};

export default SavedProperties;
